Entrada de datos:

La entrada se hace a través de inputs, donde se debe ingresar cada
valor. Si se quiere ingresar más de un valor, se debe poner un espacio 
entre ellos.
------------------------------------------------------------------
Se uso Python3 en la resolución de esta tarea, en caso de que se tenga
otra versión, cambiarlo en el Makefile.

Para correr el programa, se puede usar cualquier editor de código y correrlo
en el mismo, o también si se usa una línea de comandos (WSL, por ej), se puede 
hacer:

make P1
    correrá la pregunta numero 1

make P2
    correrá la pregunta numero 2
------------------------------------------------------------------